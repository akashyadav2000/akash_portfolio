import { heroImages, heroContent } from "../data/heroData";

import LiquidText from "./Liquidcursor";

<LiquidText lines={["intangible", "matter"]} />;

const scrollToSection = (id) => {
  const el = document.getElementById(id);
  if (!el) return;
  window.scrollTo({
    top: el.getBoundingClientRect().top + window.scrollY - 55,
    behavior: "smooth",
  });
};

export default function Hero() {
  return (
    <section
      id="home"
      className="h-[calc(100dvh-55px)] flex justify-center items-center relative overflow-hidden"
    >
      <div className="absolute inset-0 -z-10">
        <div className="w-full h-full bg-gradient-to-br from-[#c8ffc4] via-[#aefcff] to-[#ffffff] opacity-50 pointer-events-none"></div>
      </div>

      <div className="absolute inset-0 z-50 pointer-events-none hidden xl:block">
        {heroImages.map((item, index) => (
          <img
            key={index}
            src={item.src}
            alt=""
            className={item.className}
            loading="lazy"
          />
        ))}
      </div>

      <div className="flex flex-col-reverse lg:flex-row 2xl:w-[75%] xl:w-[80%] lg:w-[88%] w-[92%] lg:items-stretch items-center lg:justify-between justify-center relative z-10 lg:gap-0 lg:h-full">
        {/* Left — text */}
        <div className="flex flex-col justify-center">
          <div className="flex items-center">
            <hr className="border-t-4 border-black 2xl:w-9 xl:w-8 w-7" />
            <span className="text-black 2xl:text-[35px] xl:text-[33px] lg:text-[28px] md:text-[26px] text-[24px] font-[600] ml-[13px] leading-[1.7]">
              {heroContent.heading}
            </span>
          </div>

          <h1 className="2xl:text-[63px] xl:text-[55px] lg:text-[44px] md:text-[38px] text-[34px] font-[600] leading-[1.4]">
            {heroContent.im}{" "}
            <span className="bg-gradient-to-r from-[#0fc0fc] to-[#00ffff] bg-clip-text text-transparent">
              {heroContent.firstname}{" "}
            </span>
            <span>{heroContent.lastname}</span>
          </h1>

          <h2 className="2xl:text-[50px] xl:text-[44px] lg:text-[34px] md:text-[30px] text-[26px] font-[600] bg-gradient-to-r from-[#ff51ff] to-[#f899df] bg-clip-text text-transparent">
            {heroContent.title}
          </h2>

          <p className="text-gray-800 2xl:text-[19px] xl:text-[17px] lg:text-[15px] md:text-[15px] text-[14px] font-[500] max-w-lg leading-[1.6] my-4">
            {heroContent.description}
          </p>

          <div className="flex gap-4 flex-wrap mt-2">
            <button
              onClick={() => scrollToSection("contact")}
              className="px-6 py-2 rounded-lg font-[500] bg-white text-[#0fc0fc] border border-[#0fc0fc] transition-all duration-300 hover:bg-[#2ef6e9] hover:text-gray-800 hover:border-white text-[14px] lg:text-[15px]"
            >
              Hire Me
            </button>
            <a
              href="/certificates/resume.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-2 rounded-lg font-[500] text-white border border-white transition-all duration-300 bg-[#ff6dff] hover:bg-white hover:text-[#ff51ff] hover:border-[#ff51ff] text-[14px] lg:text-[15px]"
            >
              My Resume
            </a>
          </div>
        </div>

        {/* Right — profile image */}
        <div className="lg:w-[42%] w-[55%] sm:w-[45%] flex justify-center items-end">
          <img
            src={heroContent.profileImage}
            alt="Akash Yadav"
            className="2xl:h-[85%] xl:h-[80%] lg:h-[75%] h-[260px] sm:h-[300px] rounded-full lg:rounded-none object-contain"
          />
        </div>
      </div>
    </section>
  );
}
