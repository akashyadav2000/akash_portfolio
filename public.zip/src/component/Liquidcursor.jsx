import { useEffect, useRef } from "react";

/**
 * LiquidText
 * -----------
 * Renders text that "melts"/warps near the cursor, matching the
 * reference effect at awwwards.com/inspiration/cursor-liquid-effect
 * ("intangible matter" by Lucy Hardcastle — built with WebGL/GLSL).
 *
 * How it works:
 * 1. The given lines of text are drawn to an offscreen 2D <canvas>
 *    at high resolution — this is just a texture, never inserted
 *    into the real DOM as text, so there's no accessibility loss
 *    as long as you also render a visually-hidden real heading
 *    alongside it (see usage note below).
 * 2. That texture is uploaded to WebGL and drawn fullscreen on a
 *    <canvas>, sampled through a fragment shader.
 * 3. The shader displaces the texture's sample coordinates near the
 *    cursor — an organic noise field plus a radial push — so glyphs
 *    within `radius` of the pointer visibly bend/melt, while text
 *    further away stays crisp. Falloff is smooth (no hard edge).
 * 4. Nothing outside this component is touched. Real page content
 *    elsewhere on the site is completely unaffected.
 *
 * Usage:
 *   <LiquidText lines={["intangible", "matter"]} />
 *
 * Accessibility note: glyphs drawn to canvas are invisible to
 * screen readers. This component renders a visually-hidden
 * duplicate <h1> automatically (see `srLabel`) so the real heading
 * text is still announced/selectable/SEO-indexable.
 */

const VERTEX_SRC = `
  attribute vec2 position;
  varying vec2 vUv;
  void main() {
    vUv = position * 0.5 + 0.5;
    vUv.y = 1.0 - vUv.y; // canvas texture data is top-down; clip space is bottom-up
    gl_Position = vec4(position, 0.0, 1.0);
  }
`;

const FRAGMENT_SRC = `
  precision highp float;
  varying vec2 vUv;
  uniform sampler2D uText;
  uniform vec2 uResolution;
  uniform vec2 uMouse;       // 0..1, top-down (matches vUv space)
  uniform float uTime;
  uniform float uIntensity;  // 0..1, ramps on movement, decays when still
  uniform float uRadius;     // uv-space radius of the warped area

  float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
  }

  float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
  }

  void main() {
    vec2 uv = vUv;
    float aspect = uResolution.x / uResolution.y;

    vec2 diff = uv - uMouse;
    diff.x *= aspect; // keep the falloff circular, not elliptical
    float dist = length(diff);

    float falloff = smoothstep(uRadius, 0.0, dist) * uIntensity;

    // organic swirling field, animates slowly even while falloff is 0
    // so the puddle has life as soon as it appears
    vec2 n = vec2(
      noise(uv * 6.0 + uTime * 0.5),
      noise(uv * 6.0 + 31.7 + uTime * 0.5)
    ) - 0.5;

    // push glyphs radially away from the cursor too, for a "parting/melt" feel
    vec2 push = dist > 0.0001 ? diff / max(dist, 0.0001) : vec2(0.0);
    push.x /= aspect;

    vec2 displacement = (n * 0.07 + push * 0.05) * falloff;

    vec4 texColor = texture2D(uText, uv + displacement);
    gl_FragColor = texColor;
  }
`;

function compileShader(gl, type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error(
      "LiquidText shader compile error:",
      gl.getShaderInfoLog(shader),
    );
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}

export default function LiquidText({
  lines = ["intangible", "matter"],
  fontFamily = "Georgia, 'Times New Roman', serif",
  fontStyle = "italic",
  color = "#ffffff",
  fontSizeRatio = 0.09, // font size as a fraction of container width
  lineHeightRatio = 1.25,
  radius = 0.16, // warp radius, in uv units (0..~0.5 is reasonable)
  className = "",
  style = {},
  as: HeadingTag = "h1",
}) {
  const containerRef = useRef(null);
  const canvasRef = useRef(null);
  const rafRef = useRef(null);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    const gl = canvas.getContext("webgl", {
      alpha: true,
      premultipliedAlpha: false,
    });

    if (!gl) {
      console.warn(
        "LiquidText: WebGL not supported, falling back to static text.",
      );
      return;
    }

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const textCanvas = document.createElement("canvas");
    const textCtx = textCanvas.getContext("2d");

    let width = 0,
      height = 0;

    const drawTextTexture = () => {
      const rect = container.getBoundingClientRect();
      width = Math.max(1, rect.width);
      height = Math.max(1, rect.height);

      canvas.width = width * dpr;
      canvas.height = height * dpr;
      textCanvas.width = canvas.width;
      textCanvas.height = canvas.height;

      textCtx.clearRect(0, 0, textCanvas.width, textCanvas.height);
      textCtx.fillStyle = color;
      textCtx.textAlign = "center";
      textCtx.textBaseline = "middle";

      const fontSize = width * fontSizeRatio * dpr;
      textCtx.font = `${fontStyle} ${fontSize}px ${fontFamily}`;

      const cx = textCanvas.width / 2;
      const lineHeightPx = fontSize * lineHeightRatio;
      const totalHeight = lineHeightPx * lines.length;
      const startY = textCanvas.height / 2 - totalHeight / 2 + lineHeightPx / 2;

      lines.forEach((line, i) => {
        textCtx.fillText(line, cx, startY + i * lineHeightPx);
      });

      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texImage2D(
        gl.TEXTURE_2D,
        0,
        gl.RGBA,
        gl.RGBA,
        gl.UNSIGNED_BYTE,
        textCanvas,
      );
    };

    const vertexShader = compileShader(gl, gl.VERTEX_SHADER, VERTEX_SRC);
    const fragmentShader = compileShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SRC);
    const program = gl.createProgram();
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);

    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      console.error(
        "LiquidText: program link error:",
        gl.getProgramInfoLog(program),
      );
      return;
    }
    gl.useProgram(program);

    const quadBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, quadBuffer);
    gl.bufferData(
      gl.ARRAY_BUFFER,
      new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]),
      gl.STATIC_DRAW,
    );
    const positionLoc = gl.getAttribLocation(program, "position");
    gl.enableVertexAttribArray(positionLoc);
    gl.vertexAttribPointer(positionLoc, 2, gl.FLOAT, false, 0, 0);

    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

    const uText = gl.getUniformLocation(program, "uText");
    const uResolution = gl.getUniformLocation(program, "uResolution");
    const uMouse = gl.getUniformLocation(program, "uMouse");
    const uTime = gl.getUniformLocation(program, "uTime");
    const uIntensity = gl.getUniformLocation(program, "uIntensity");
    const uRadius = gl.getUniformLocation(program, "uRadius");

    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

    drawTextTexture();

    let targetU = 0.5,
      targetV = 0.5;
    let mouseU = 0.5,
      mouseV = 0.5;
    let intensity = 0;

    const onMove = (e) => {
      const rect = container.getBoundingClientRect();
      const x = e.clientX ?? e.touches?.[0]?.clientX;
      const y = e.clientY ?? e.touches?.[0]?.clientY;
      if (x == null) return;
      targetU = (x - rect.left) / rect.width;
      targetV = (y - rect.top) / rect.height;
      intensity = Math.min(intensity + 0.15, 1);
    };
    const onLeave = () => {
      intensity = 0;
    };

    window.addEventListener("mousemove", onMove);
    window.addEventListener("touchmove", onMove, { passive: true });
    window.addEventListener("mouseleave", onLeave);

    const resizeObserver = new ResizeObserver(() => drawTextTexture());
    resizeObserver.observe(container);

    const render = (t) => {
      rafRef.current = requestAnimationFrame(render);

      mouseU += (targetU - mouseU) * 0.12;
      mouseV += (targetV - mouseV) * 0.12;
      intensity *= 0.965;

      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);

      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.uniform1i(uText, 0);
      gl.uniform2f(uResolution, canvas.width, canvas.height);
      gl.uniform2f(uMouse, mouseU, mouseV);
      gl.uniform1f(uTime, t * 0.001);
      gl.uniform1f(uIntensity, intensity);
      gl.uniform1f(uRadius, radius);

      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    };
    rafRef.current = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(rafRef.current);
      resizeObserver.disconnect();
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("touchmove", onMove);
      window.removeEventListener("mouseleave", onLeave);
      gl.deleteProgram(program);
      gl.deleteShader(vertexShader);
      gl.deleteShader(fragmentShader);
      gl.deleteBuffer(quadBuffer);
      gl.deleteTexture(texture);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    lines.join("|"),
    fontFamily,
    fontStyle,
    color,
    fontSizeRatio,
    lineHeightRatio,
    radius,
  ]);

  return (
    <div
      ref={containerRef}
      className={className}
      style={{ position: "relative", width: "100%", ...style }}
    >
      {/* Real heading, kept for accessibility/SEO/selection — visually
          hidden since the canvas renders the visible version on top. */}
      <HeadingTag
        style={{
          position: "absolute",
          width: "1px",
          height: "1px",
          overflow: "hidden",
          clip: "rect(0 0 0 0)",
          whiteSpace: "nowrap",
        }}
      >
        {lines.join(" ")}
      </HeadingTag>

      <canvas
        ref={canvasRef}
        style={{
          display: "block",
          width: "100%",
          height: "100%",
          minHeight: "200px",
          pointerEvents: "none",
        }}
      />
    </div>
  );
}
