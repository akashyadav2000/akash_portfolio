import React from "react";
import { projects } from "../data/portfolioData";
import linkIcon from "/images/project/download.svg";

export default function Portfolio() {
  return (
    <section
      id="projects"
      className="relative w-full min-h-fit xl:min-h-[calc(100dvh-55px)] flex flex-col justify-center items-center px-[5%] sm:px-[6%] lg:px-[8%] xl:px-[11%] py-8 xl:py-6"
    >
      <div className="absolute inset-0 -z-10">
        <div className="w-full h-full bg-gradient-to-br from-[#dea8ff] via-[#deffd8] to-[#ffa8de] opacity-40"></div>
      </div>

      <div className="w-full max-w-[1500px]">
        <h2 className="2xl:text-[34px] xl:text-[32px] lg:text-[28px] text-[24px] leading-none font-semibold text-center text-gray-800 mb-6 xl:mb-[3%]">
          Portfolio
        </h2>

        {/* 1 col mobile, 2 col sm, 3 col lg */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 xl:gap-x-10 xl:gap-y-10 2xl:gap-x-14 2xl:gap-y-14">
          {projects.map((project, index) => (
            <div
              key={index}
              className="rounded-lg overflow-hidden transition-all duration-500 group border border-white shadow-md"
            >
              {/* Fixed height responsive: smaller on mobile, grows on larger screens */}
              <div className="w-full h-[200px] sm:h-[220px] lg:h-[26vh] xl:h-[29vh] 2xl:h-[32vh] relative">
                <img
                  src={project.image}
                  alt={project.title}
                  loading="lazy"
                  className="w-full h-full object-cover object-left transition-all duration-500 group-hover:scale-105 group-hover:blur-[4px]"
                />

                {/* FIXED: was white text on near-white cyan — very poor contrast.
                    Now dark teal overlay with white text + drop shadow = readable on all screens */}
                <div className="absolute inset-0 bg-gradient-to-b from-[#005f5f]/80 via-[#008080]/90 to-[#006060] flex flex-col justify-center items-center text-center py-4 px-[8%] opacity-0 translate-y-full group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500 ease-in-out">
                  <h4 className="text-[16px] lg:text-[17px] xl:text-[19px] 2xl:text-[21px] font-semibold text-white drop-shadow-[1px_1.5px_0px_rgba(0,0,0,0.6)] mb-1">
                    {project.title}
                  </h4>
                  <p className="text-[12px] lg:text-[13px] xl:text-[14px] 2xl:text-[15px] mt-1 mb-3 text-white font-medium leading-[1.5]">
                    {project.description}
                  </p>
                  <a
                    href={project.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`Visit ${project.title}`}
                    className="w-[34px] h-[34px] xl:w-[38px] xl:h-[38px] bg-white rounded-full flex items-center justify-center shadow-lg transition hover:scale-110"
                  >
                    <img
                      src={linkIcon}
                      alt=""
                      className="w-[16px] xl:w-[18px]"
                    />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
